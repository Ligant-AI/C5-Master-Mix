// @ligant/bench-chrome: the header and footer every Ligant Bench Tool shares.
//
// Framework-free: every renderer returns an HTML string, so the plain-JS tools
// set it as innerHTML and the React tools render it through `./react.js`. A tool
// supplies only what is its own (its path, title, description, repository
// and citations); everything else, including the list of tools and
// the privacy statement, is here, so it is written once for the whole suite.
//
// No runtime dependency. The renderers contact nothing and store nothing. The
// one exception is the privacy choice in ./consent.js, which bindCopy (and so
// SuiteFooter) starts: it stores the visitor's Allow or Decline, and only after
// Allow loads Google Analytics from www.googletagmanager.com. The addresses the
// renderers embed are the suite's own (SITE_URL), the parent site (LIGANT_URL),
// the Privacy Policy (PRIVACY_URL) and the SVG namespace in the favicon.
//
// The stylesheet is a separate export (`@ligant/bench-chrome/chrome.css`) that a
// tool imports from its own entry point. It is not imported here, so this module
// also loads under plain Node, where tools run their tests.

import { initConsent } from './consent.js';

export { initConsent, GA_ID, GA_SCRIPT_URL, CONSENT_KEY, CONSENT_VERSION, BANNER_TEXT } from './consent.js';

export const SITE_URL = 'https://benchtools.ligant.ai';
export const LIGANT_URL = 'https://ligant.ai/';
export const PRIVACY_URL = 'https://ligant.ai/privacy';
export const PRIVACY_CHOICES_URL = `${PRIVACY_URL}#google-analytics`;
export const SUITE_LABEL = 'Bench Tools';

/**
 * The suite, in the order the tool switcher presents it. Add a tool here only
 * once it is live at `path`: a pill that 404s is worse than a tool the
 * navigation does not mention yet. A release of this package that adds one has
 * to reach every tool before every header shows it.
 */
export const TOOLS = Object.freeze([
  { id: 'antibody-titration', label: 'Antibody titration', path: '/antibody-titration-planner/' },
  { id: 'molarity', label: 'Molarity', path: '/molarity-converter/' },
  { id: 'antigen-density', label: 'Antigen density', path: '/antigen-density-calculator/' },
  { id: 'dilution', label: 'Dilution', path: '/dilution-planner/' },
  { id: 'master-mix', label: 'Master mix', path: '/master-mix/' },
  { id: 'reconstitution', label: 'Reconstitution', path: '/reconstitution/' },
  { id: 'titration-analysis', label: 'Titration analysis', path: '/titration-analysis/' },
  { id: 'digital-pcr', label: 'Digital PCR', path: '/digital-pcr-calculator/' },
  { id: 'cell-counting', label: 'Cell counting', path: '/cell-counting-and-seeding/' },
  { id: 'rpm-to-g', label: 'RPM to g', path: '/rpm-to-g/' },
  { id: 'a280-dol', label: 'A280 and Degree of Labelling', path: '/a280-and-degree-of-labelling/' },
  { id: 'nucleic-acid-mass', label: 'Nucleic acid mass and copies', path: '/nucleic-acid-mass-and-copies/' },
  { id: 'media-buffer-prep', label: 'Media and buffer prep', path: '/media-and-buffer-prep/' },
]);

/** The standard privacy statement, word for word the same in every tool.
 *  Vendor-neutral since 1.8.1 (Warden, 21 Oct 2026, item 3; approved by A.B.,
 *  22 Oct 2026). The recipients are named where consent is asked and recorded:
 *  the banner (BANNER_TEXT, ./consent.js) and the Privacy Policy. */
export const PRIVACY_STATEMENT =
  'Everything you enter into this calculator stays on your computer. Calculations run entirely in your browser, and your inputs are never transmitted, stored, or logged. The newsletter signup at the foot of this page is separate: only an email address you choose to submit there is sent to us. We use web analytics to count visits and see how quickly this page loads, so we can improve the tools, and further analytics only if you allow it in the banner. No analytics ever receives anything you type into this tool.';

export const OPEN_SOURCE_STATEMENT =
  'Ligant Bench Tools are free and open source under Apache 2.0. Research use only. Not qualified for GxP decision-making.';

export const ENTERPRISE_STATEMENT =
  "These tools are standalone calculators. For GxP work, Ligant offers a separate enterprise product. If your lab needs that, please email us";

export const LEGAL_ENTITY = 'Ligant AI Incorporated';
export const ADDRESS = Object.freeze(['3675 Market Street', 'Suite 200', 'Philadelphia PA 19104']);
export const CONTACT_EMAIL = 'hello@ligant.ai';

/** The absolute address of a path in the suite. Absolute, not root-relative:
 *  each tool is also reachable at its own *.pages.dev origin, where the
 *  siblings' paths do not exist. */
export function suiteUrl(path) {
  return `${SITE_URL}${path.startsWith('/') ? path : `/${path}`}`;
}

export function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
const esc = escapeHtml;

const NEW_TAB = '<span class="visually-hidden"> (opens in a new tab)</span>';
function externalLink(href, html) {
  return `<a href="${esc(href)}" target="_blank" rel="noopener noreferrer">${html}${NEW_TAB}</a>`;
}

// ---------------------------------------------------------------------------
// The Ligant mark: "Council · Ringed" (Brand Guidelines v1.1 §03). The table is
// the hexagon, the six dots are the agents, the amber centre is the human who
// decides. viewBox 32, tile radius 7.04 (22%), agents on a circle of radius 9.2
// at 60° from the top, dot radius 2.1, centre radius 3.6, table stroke 1.7 with
// round joins. §03 forbids re-deriving these numbers.

const AGENT_RING = 9.2;
const AGENT_R = 2.1;
const CENTRE_R = 3.6;
const TILE_RX = 7.04;
const AGENTS = Array.from({ length: 6 }, (_, i) => {
  const a = (-90 + i * 60) * (Math.PI / 180);
  return [16 + AGENT_RING * Math.cos(a), 16 + AGENT_RING * Math.sin(a)];
});
const TABLE = `${AGENTS.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${x.toFixed(3)},${y.toFixed(3)}`).join(' ')} Z`;

/**
 * The mark as inline SVG. Inline because an asset request is a request.
 * @param {{ size?: number, variant?: 'tile' | 'plain', title?: string }} [o]
 */
export function markSvg({ size = 28, variant = 'tile', title = '' } = {}) {
  const tile = variant === 'tile';
  const ink = tile ? 'var(--brand-offwhite, #FAF7F2)' : 'var(--brand-teal, #0D7C66)';
  return [
    `<svg class="ligant-mark" width="${size}" height="${size}" viewBox="0 0 32 32" role="${title ? 'img' : 'presentation'}"`,
    title ? ` aria-label="${esc(title)}">` : ' aria-hidden="true">',
    tile ? `<rect width="32" height="32" rx="${TILE_RX}" fill="var(--brand-teal, #0D7C66)"/>` : '',
    `<path d="${TABLE}" fill="none" stroke="${ink}" stroke-width="1.7" stroke-linejoin="round"/>`,
    AGENTS.map(([x, y]) => `<circle cx="${x.toFixed(3)}" cy="${y.toFixed(3)}" r="${AGENT_R}" fill="${ink}"/>`).join(''),
    `<circle cx="16" cy="16" r="${CENTRE_R}" fill="var(--brand-amber-mark, #E0A416)"/>`,
    '</svg>',
  ].join('');
}

/** Horizontal lockup, mark and "Ligant": the default for headers (§03). */
export function lockupHtml(size = 28) {
  return `<span class="lockup">${markSvg({ size })}<span class="wordmark">Ligant</span></span>`;
}

/** The mark as a data URI, for the favicon. No network request. */
export function markDataUri() {
  const svg = [
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">',
    `<rect width="32" height="32" rx="${TILE_RX}" fill="#0D7C66"/>`,
    // The table thickened to 2 at favicon size so it never fills in (§03).
    `<path d="${TABLE}" fill="none" stroke="#FAF7F2" stroke-width="2" stroke-linejoin="round"/>`,
    AGENTS.map(([x, y]) => `<circle cx="${x.toFixed(3)}" cy="${y.toFixed(3)}" r="${AGENT_R}" fill="#FAF7F2"/>`).join(''),
    `<circle cx="16" cy="16" r="${CENTRE_R}" fill="#E0A416"/>`,
    '</svg>',
  ].join('');
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}

// ---------------------------------------------------------------------------
// The header. Rendered INTO `<header class="masthead">`, which the tool owns so
// the element exists before any script runs.

/**
 * @param {{ path: string, title: string, description?: string | string[] }} tool
 *   `path` is this tool's own mount point, e.g. '/dilution-planner/', which is
 *   how the switcher knows which pill is the current page.
 */
export function renderHeader({ path, title, description = [] }) {
  const paras = (Array.isArray(description) ? description : [description]).filter(Boolean);
  const current = TOOLS.find((t) => t.path === path);
  const item = (t) => `<li>${t.path === path
    ? `<span aria-current="page">${esc(t.label)}</span>`
    : `<a href="${esc(suiteUrl(t.path))}">${esc(t.label)}</a>`}</li>`;
  const nav = TOOLS.map(item).join('');
  const suiteLink = (cls) => `<a class="${cls}" href="${esc(suiteUrl('/'))}">${esc(SUITE_LABEL)}</a>`;
  // Two renderings of the same addresses, never both visible: the tab list
  // (chrome.css hides it at 760px and below) and a native <details> disclosure
  // (hidden above 760px with display: none, so it is not read twice). A closed
  // <details> cannot be forced open without script, hence two lists. The summary
  // names the current tool; "Switch tool" is its screen-reader label.
  const menu = `<details class="tool-menu">`
    + `<summary><span class="visually-hidden">Switch tool: </span><span class="tool-menu-current">${esc(current ? current.label : SUITE_LABEL)}</span></summary>`
    + `<ul class="tool-menu-list">${nav}<li class="tool-menu-suite">${suiteLink('suite-mark')}</li></ul>`
    + `</details>`;
  return `<div class="masthead-titles">`
    + `<a class="lockup-link" href="${esc(LIGANT_URL)}">${lockupHtml(28)}</a>`
    + `<h1>${esc(title)}</h1>`
    + paras.map((p) => `<p>${esc(p)}</p>`).join('')
    + `</div>`
    + `<nav class="tool-nav" aria-label="${esc(SUITE_LABEL)}">`
    + `<ul class="tool-tabs">${nav}</ul>`
    + suiteLink('eyebrow suite-mark tool-suite-mark')
    + menu
    + `</nav>`;
}

// ---------------------------------------------------------------------------
// Newsletter signup, at the top of the footer.
//
// The form posts same-origin to /api/subscribe, which the catalog Worker on
// benchtools.ligant.ai forwards to the ligant.ai Worker. That route exists only
// there, so anywhere else (a *.pages.dev address, a local copy) the form stays
// hidden and a link to the signup on ligant.ai is shown instead. The address
// is the only thing it sends; nothing is added to a list until the person
// confirms by email.

export const NEWSLETTER_HOSTS = Object.freeze(['benchtools.ligant.ai']);
export const NEWSLETTER_ENDPOINT = '/api/subscribe';
export const NEWSLETTER_TEXT = 'New open source bench tools, and practical notes on using AI in GxP-regulated work. Occasional emails. Unsubscribe any time.';
const NEWSLETTER_POLICY = `${PRIVACY_URL}#newsletter`;

export function renderNewsletter() {
  return `<section class="footer-newsletter" aria-labelledby="ligant-nl-title">`
    + `<h2 class="footer-newsletter-title" id="ligant-nl-title">Get updates from Ligant</h2>`
    + `<p class="footer-newsletter-text">${esc(NEWSLETTER_TEXT)}</p>`
    + `<form class="footer-newsletter-form" data-newsletter hidden novalidate>`
    + `<label class="footer-newsletter-label" for="ligant-nl-email">Email address</label>`
    + `<div class="footer-newsletter-row">`
    + `<input id="ligant-nl-email" name="email" type="email" autocomplete="email" maxlength="254" required>`
    + `<button type="submit">Subscribe</button>`
    + `</div>`
    + `<label class="footer-newsletter-consent"><input type="checkbox" name="consent" required>`
    + `<span>I agree to receive these emails. We will ask you to confirm first. ${externalLink(NEWSLETTER_POLICY, 'How we use your address')}</span></label>`
    + `<div class="footer-newsletter-hp" aria-hidden="true"><label>Leave this empty <input name="website" type="text" tabindex="-1" autocomplete="off"></label></div>`
    + `<p class="footer-newsletter-status" role="status" aria-live="polite"></p>`
    + `</form>`
    + `<p class="footer-newsletter-text" data-newsletter-elsewhere>Sign up at ${externalLink(`${LIGANT_URL}#newsletter`, 'ligant.ai')}.</p>`
    + `</section>`;
}

/** Shows and wires the signup inside `root`, where the endpoint exists. */
export function bindNewsletter(root) {
  if (typeof document === 'undefined' || !root?.querySelectorAll) return () => {};
  const here = typeof location !== 'undefined' ? location.hostname : '';
  if (!NEWSLETTER_HOSTS.includes(here)) return () => {};
  const cleanups = [];
  for (const form of root.querySelectorAll('form[data-newsletter]')) {
    const section = form.closest('.footer-newsletter');
    const elsewhere = section?.querySelector('[data-newsletter-elsewhere]');
    const status = form.querySelector('.footer-newsletter-status');
    const button = form.querySelector('button');
    const email = form.querySelector('input[name="email"]');
    const consent = form.querySelector('input[name="consent"]');
    const website = form.querySelector('input[name="website"]');
    const say = (text, kind = '') => {
      status.textContent = text;
      status.className = `footer-newsletter-status${kind ? ` is-${kind}` : ''}`;
    };
    form.hidden = false;
    if (elsewhere) elsewhere.hidden = true;
    const onSubmit = async (event) => {
      event.preventDefault();
      const value = email.value.trim();
      if (!value || !email.checkValidity()) { say('Please enter a valid email address.', 'error'); email.focus(); return; }
      if (!consent.checked) { say('Please tick the box to agree to receive these emails.', 'error'); consent.focus(); return; }
      button.disabled = true;
      say('Sending...');
      try {
        const res = await fetch(NEWSLETTER_ENDPOINT, {
          method: 'POST',
          credentials: 'omit',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ email: value, consent: true, website: website ? website.value : '' }),
        });
        const data = await res.json().catch(() => ({}));
        if (res.status === 202) { form.reset(); say('Almost done. Check your inbox for an email asking you to confirm.', 'ok'); }
        else if (res.status === 400) say('Please check your email address and try again.', 'error');
        else if (res.status === 503 && data?.error === 'not_open') say('Signups are not open yet. Please try again soon.', 'error');
        else say('Something went wrong. Please try again later.', 'error');
      } catch {
        say('Something went wrong. Please try again later.', 'error');
      } finally {
        button.disabled = false;
      }
    };
    form.addEventListener('submit', onSubmit);
    cleanups.push(() => form.removeEventListener('submit', onSubmit));
  }
  return () => cleanups.forEach((c) => c());
}

// ---------------------------------------------------------------------------
// The footer. Rendered INTO `<footer class="site-footer">`.

/**
 * @typedef {{ lead: string, title: string, tail: string, what?: string }} Citation
 *   Shown as lead + <cite>title</cite> + tail and copied as the same three
 *   concatenated, so what is shown and what is copied cannot differ. `what`
 *   names the work in the copy button's label ("Copy the software citation").
 */

/**
 * @param {{
 *   repoUrl: string,
 *   citations: Citation[],
 *   disclaimer?: string,
 *   citationNote?: string,
 *   citationFootnote?: string,
 *   localCopyHtml?: string,
 * }} tool
 *   `repoUrl` is this tool's own repository; the package never holds one.
 *   `localCopyHtml` is trusted markup from the tool, for the sentence after the
 *   repository link; the default tells a reader how to run a local copy.
 *   `disclaimer` is deprecated since 1.7.0 and ignored: the research-use
 *   sentence appears once on the page, in OPEN_SOURCE_STATEMENT (A.B., 15 Oct
 *   2026). It is still accepted so that no tool's call breaks.
 */
export function renderFooter({
  repoUrl,
  citations,
  disclaimer: _deprecatedDisclaimer,
  citationNote = 'Cite the software as below.',
  citationFootnote = '',
  localCopyHtml = 'Clone it and <code>npm run dev</code> for a local copy.',
}) {
  const mail = `<a href="mailto:${esc(CONTACT_EMAIL)}">${esc(CONTACT_EMAIL)}</a>`;
  const repoLabel = esc(repoUrl.replace(/^https?:\/\//, ''));
  const rows = citations.map(({ lead, title, tail, what = 'software' }) => `<div class="footer-citation-row">`
    + `<p>${esc(lead)}<cite>${esc(title)}</cite>${esc(tail)}</p>`
    + `<button type="button" data-copy-citation aria-label="Copy the ${esc(what)} citation" aria-live="polite">Copy</button>`
    + `</div>`).join('');
  return renderNewsletter()
    + `<div class="footer-grid">`
    + `<div class="footer-prose">`
    + `<p>${esc(OPEN_SOURCE_STATEMENT)} <strong>Privacy.</strong> ${esc(PRIVACY_STATEMENT)} ${externalLink(PRIVACY_URL, 'Privacy Policy')} · <a href="${esc(PRIVACY_CHOICES_URL)}" data-privacy-choices>Privacy choices</a></p>`
    + `<p>Every figure on this page comes from code you can read, download or run yourself, at ${externalLink(repoUrl, repoLabel)}. ${localCopyHtml}</p>`
    + `<p>${esc(ENTERPRISE_STATEMENT)} ${mail}.</p>`
    + `</div>`
    + `<address class="footer-address"><span class="eyebrow">${esc(LEGAL_ENTITY)}</span>${ADDRESS.map(esc).join('<br>')}<br>${mail}</address>`
    + `</div>`
    + `<div class="footer-citation">`
    + `<span class="eyebrow">How to cite</span>`
    + `<p class="footer-citation-note">${esc(citationNote)}</p>`
    + rows
    + (citationFootnote ? `<p class="footer-citation-note">${esc(citationFootnote)}</p>` : '')
    + `</div>`
    // The spaces either side of the LICENSE link are literal: tools test for
    // the "theLICENSE" rendering they once had.
    + `<p class="footer-licence">Licensed under the Apache License, Version 2.0. You may obtain a copy of the License in the `
    + `<a href="./LICENSE" target="_blank" rel="noopener"><code>LICENSE</code>${NEW_TAB}</a>`
    + ` file served with this page and distributed with the source. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" basis, without warranties or conditions of any kind, either express or implied.</p>`;
}

/**
 * Wires the footer's copy buttons, by delegation on `root`, so it survives the
 * footer being re-rendered. Also starts the suite's privacy choice (see
 * ./consent.js), which the footer's "Privacy choices" link reopens: every tool
 * that renders the suite footer asks before Google Analytics loads. "Copied" is shown only once the write resolves;
 * where the clipboard is refused, the citation is selected instead, so it can
 * still be taken by hand. Returns a function that removes the listener.
 * @param {Element} root
 */
export function bindCopy(root) {
  initConsent();
  const onClick = async (event) => {
    const button = event.target instanceof Element ? event.target.closest('[data-copy-citation]') : null;
    if (!button || !root.contains(button)) return;
    const text = button.closest('.footer-citation-row')?.querySelector('p');
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text.textContent ?? '');
      button.textContent = 'Copied';
      setTimeout(() => { button.textContent = 'Copy'; }, 2000);
    } catch {
      const range = document.createRange();
      range.selectNodeContents(text);
      const selection = getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
    }
  };
  root.addEventListener('click', onClick);
  const unbindNewsletter = bindNewsletter(root);
  return () => { root.removeEventListener('click', onClick); unbindNewsletter(); };
}
